<?php 
require_once __DIR__ . '/_header_kosarica.php'; 


if( isset($msg) ){
    echo $msg . '<br>';
}
?>
<hr>
<br>


<?php  require_once __DIR__ . '/_footer.php' ?>