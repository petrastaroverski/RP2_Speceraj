<?php require_once __DIR__ . '/_header.php'; ?>


<form action="index.php?rt=products/searchProducts" method="post">
    <h1 class="podnaslov">Čime želite napuniti košaricu? <h1>
        <textarea  name="search" rows="4" cols="80"></textarea>
    <br> 
    <br>
    <button type="submit" id="srch"> Pretraži trgovine! </button>




<?php require_once __DIR__ . '/_footer.php'; ?> 
